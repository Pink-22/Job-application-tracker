-- Run this file in MySQL to set up the database
CREATE DATABASE IF NOT EXISTS job_tracker;
USE job_tracker;

CREATE TABLE IF NOT EXISTS applications (
    id            INT AUTO_INCREMENT PRIMARY KEY,
    company_name  VARCHAR(100) NOT NULL,
    role          VARCHAR(100) NOT NULL,
    date_applied  DATE NOT NULL,
    status        ENUM('Applied','Interview','Rejected','Offered') DEFAULT 'Applied',
    notes         TEXT,
    follow_up_date DATE,
    created_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Sample data
INSERT INTO applications (company_name, role, date_applied, status, notes, follow_up_date) VALUES
('Google', 'Software Engineer', '2024-01-10', 'Interview', 'Round 1 cleared', '2024-01-20'),
('Infosys', 'Java Developer', '2024-01-12', 'Applied', 'Waiting for response', '2024-01-25'),
('TCS', 'Web Developer', '2024-01-05', 'Rejected', 'Not selected', NULL),
('Wipro', 'Backend Developer', '2024-01-15', 'Offered', 'Offer received!', NULL);
